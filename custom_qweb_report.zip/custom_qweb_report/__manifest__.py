# License AGPL-3.0 or later (https://www.gnu.org/licenses/agpl.html).
{
    'name': "Custom Qweb Report",
    'summary': "Impresion personalizada del cliente",
    'author': 'Pedro MBE',
    'website': "www.finanzasycontabilidadaa.com",
    'category': 'Base',
    'version': '12.0.1.0.0',
    'license': 'AGPL-3',
    'depends': [
        'base', 'web', 'sale',
    ],
    'data': [
        'views/assets.xml',
        'report/sale_order_report_template.xml',
        'views/custom_external_layout.xml',
    ],
    'css': [
        'static/css/font_style.css',
        'static/css/report_style.css',
    ],
    'installable': True,
}
